#include "Touch_Utility.h"

TOUCH_INFO touch_info;
GTPoint *Privious_TP;