#include <GT911.h>

#define MAX_LCD_HEIGTH 32
#define MAX_LCD_WIDTH 64

typedef struct
{
    int Privious_X_Touch;
    int Privious_Y_Touch;
    int Current_X_Touch;
    int Current_Y_Touch;
}TOUCH_INFO;

extern TOUCH_INFO touch_info;
extern GTPoint *Privious_TP;